private static final String[] CURSOR_COLUMNS = new String[]
{
   BaseColumns._ID,
   LiveFolders.NAME,
   LiveFolders.DESCRIPTION,
   LiveFolders.INTENT,
   LiveFolders.ICON_PACKAGE,
   LiveFolders.ICON_RESOURCE
};


