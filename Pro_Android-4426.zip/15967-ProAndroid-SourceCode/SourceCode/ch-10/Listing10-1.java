glDrawElements(
   // type of shape
   GL10.GL_TRIANGLE_STRIP,
   // Number of indices
   3,
   // How big each index is
   GL10.GL_UNSIGNED_SHORT,
   // buffer containing the 3 indices
   mIndexBuffer);


