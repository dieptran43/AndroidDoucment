@Override
public boolean onContextItemSelected(MenuItem item)
{
   if (item.itemId() = some-menu-item-id)
   {
      //handle this menu item
      return true;
   }
   //... other exception processing
}


