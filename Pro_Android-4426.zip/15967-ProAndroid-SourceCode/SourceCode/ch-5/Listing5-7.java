public class SampleMenusActivity extends Activity 
{
   //Initialize this in onCreateOptions
   Menu myMenu = null;
   @Override
   public void onCreate(Bundle savedInstanceState) 
   {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.main);
   }
   //....other code
}


