GP2XWolf3D v0.3
ported by TJ Hooka
Based on icculus.org's linux port of Wolf3D and some stuff in the GP32 port of Wolf3D by Flav0r

Well, I've managed to get it running and alot better than I had hoped for this quick!
So far it's running nice (although it slows down sometimes) and has music and sfx and save/load now too! (although saving and loading you can only use vol+ as M and Y button as y for the name for now, I hope to get it like the GP32 version's name input scheme except I want it to save the name properly :P)

To play copy the contents (including all subdirectories) into the root of your SD card (if you want to change this you can, just edit the scripts in the root) and copy the game data files into there respective directories (for example wolf3d shareware into /wolf3d/wolf3dsw/) Now DaveC if you can't handle how this is done, I'm sorry but I don't feel like hard coding in the paths, scripts are much easier and this way I can make it exit back out to the menu afterwards :P

Controls are pretty much like the GP32 version except run and open aren't a shared button anymore :D

A is Open Door
X is Shoot
B is run
Y is Y for any questions that pop up
L is for Left Strafe
R is for Right Strafe
START is used as escape, so in any menu or pop up box you can use it to go back
SELECT is change weapon
Joystick click is for RETURN, and as far as I've noticed is only needed for saving

As you might have noticed I've also added support for SOD mission 2 and 3, I'm sorry if this is a teaser to most (if not all) but I own them and enjoy playing them even if they have blue guns :P There's also cheats now, so figure 'em out!

Well, if you feel anything is missing or needs to be fixed please drop me a line at hooka(Op)telusplanet(period!)net 

Enjoy!